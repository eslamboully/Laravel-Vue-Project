require('./bootstrap');

import Vue from 'vue';
import VueRouter from 'vue-router';
import { Form, HasError, AlertError } from 'vform';

Vue.use(VueRouter);
Vue.component(HasError.name, HasError);
Vue.component(AlertError.name, AlertError);
window.Form = Form;
import HomeComponent from "./components/HomeComponent";
import ProfileComponent from "./components/ProfileComponent";
import UserComponent from "./components/UserComponent";

const routes = [
    { path: '/home', component: HomeComponent },
    { path: '/profile', component: ProfileComponent },
    { path: '/users', component: UserComponent },
];

const router = new VueRouter({
    routes,
    linkActiveClass: "active",
    mode: 'history'
});

const app = new Vue({
    el: '#app',
    router
});
