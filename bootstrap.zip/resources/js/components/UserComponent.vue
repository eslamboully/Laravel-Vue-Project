<template>
   <div>
       <!-- Content Header (Page header) -->
       <div class="content-header">
           <div class="container-fluid">
               <div class="row mb-2">
                   <div class="col-sm-6">
<!--                       <h1 class="m-0 text-dark">Users</h1>-->
                   </div><!-- /.col -->
                   <div class="col-sm-6">
<!--                       <ol class="breadcrumb float-sm-right">-->
<!--                           <li class="breadcrumb-item"><a href="#">Home</a></li>-->
<!--                           <li class="breadcrumb-item active">Users</li>-->
<!--                       </ol>-->
                   </div><!-- /.col -->
               </div><!-- /.row -->
           </div><!-- /.container-fluid -->
       </div>
       <!-- /.content-header -->

       <!-- Main content -->
       <section class="content">
           <div class="container-fluid">
               <div class="row">
                   <div class="col-12">
                       <div class="card">
                           <div class="card-head">
                               <h3 class="card-header">Users Table<button type="button" class="btn btn-success" style="float: right" data-toggle="modal" data-target="#createUser">Add User <i class="fa fa-user-plus"></i></button></h3>
                           </div>
                           <!-- /.card-header -->
                           <div class="card-body">
                               <table id="example2" class="table table-bordered table-hover">
                                   <thead>
                                   <tr>
                                       <th>#</th>
                                       <th>Name</th>
                                       <th>Email</th>
                                       <th>Type</th>
                                       <th>Action</th>
                                   </tr>
                                   </thead>
                                   <tbody>
                                   <tr v-for="user in users.data.data" :key="user.id">
                                       <td>{{ user.id }}</td>
                                       <td>{{ user.name }}</td>
                                       <td>{{ user.email }}</td>
                                       <td>{{ user.type }}</td>
                                       <td>
                                           <a href="#"><i class="fa fa-edit"></i></a>
                                           <a href="#"><i class="fa fa-trash" style="color: red"></i></a>
                                       </td>
                                   </tr>
                                   </tbody>
                               </table>
                           </div>
                           <!-- /.card-body -->
                       </div>
                       <!-- /.card -->
                   </div>
                   <!-- /.col -->
               </div>
           </div><!-- /.container-fluid -->
       </section>
       <div class="modal fade" id="createUser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
           <div class="modal-dialog" role="document">
               <div class="modal-content">
                   <div class="modal-header">
                       <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                       </button>
                   </div>
                   <form @submit.prevent="createUser" @keydown="form.onKeydown($event)">
                   <div class="modal-body">
                           <div class="form-group">
                               <label>Name</label>
                               <input v-model="form.name" type="text" name="name"
                                      class="form-control" :class="{ 'is-invalid': form.errors.has('name') }">
                               <has-error :form="form" field="name"></has-error>
                           </div>
                           <div class="form-group">
                               <label>Email</label>
                               <input v-model="form.email" type="email" name="email"
                                      class="form-control" :class="{ 'is-invalid': form.errors.has('email') }">
                               <has-error :form="form" field="email"></has-error>
                           </div>
                           <div class="form-group">
                               <label>Bio</label>
                               <textarea v-model="form.bio" name="bio"
                                      class="form-control" :class="{ 'is-invalid': form.errors.has('bio') }">
                               </textarea>
                               <has-error :form="form" field="bio"></has-error>
                           </div>

                           <div class="form-group">
                               <label>Email</label>
                               <select v-model="form.type" name="type"
                                      class="form-control" :class="{ 'is-invalid': form.errors.has('type') }">
                                   <option value="">Select User Role</option>
                                   <option value="admin">Admin</option>
                                   <option value="user">standard User</option>
                                   <option value="author">Author</option>
                               </select>
                               <has-error :form="form" field="type"></has-error>
                           </div>
                           <div class="form-group">
                               <label>Password</label>
                               <input v-model="form.password" type="password" name="password"
                                      class="form-control" :class="{ 'is-invalid': form.errors.has('password') }">
                               <has-error :form="form" field="password"></has-error>
                           </div>


                   </div>
                   <div class="modal-footer">
                       <button type="button" :disabled="form.busy" class="btn btn-danger" data-dismiss="modal">Close</button>
                       <button type="submit" :disabled="form.busy" class="btn btn-success">Create User</button>
                   </div>
                   </form>
               </div>
           </div>
       </div>
   </div>
</template>

<script>
    export default {
        data() {
            return {
                users : {},
                form: new Form({
                    name: '',
                    email: '',
                    password: '',
                    type: '',
                    bio: '',
                    photo: '',
                })
            }
        },
        methods: {
            loadUsers() {
                axios.get('api/user').then(response => (this.users = response))
            },
            createUser() {
                this.form.post('api/user')
            }
        },
        created() {
            this.loadUsers();
        }
    }

</script>
